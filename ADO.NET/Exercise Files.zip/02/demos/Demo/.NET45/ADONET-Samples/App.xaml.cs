﻿using System.Windows;

namespace ADONET_Samples
{
  public partial class App : Application
  {
  }
}
