﻿using System.Windows.Controls;

namespace ADONET_Samples.UserControls
{
  public partial class ProductDetailControl : UserControl
  {
    public ProductDetailControl()
    {
      InitializeComponent();
    }
  }
}
