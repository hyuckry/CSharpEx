﻿ADO.NET Samples
----------------------------------------------
ConnectionControl - Connecting to a database
  - Window Auth
  - SQL Server Auth
  - Using block
  - Show an exception
  - www.connectionstrings.com

CommandControl - Using the SqlCommand to submit queries, with and without parameters
  - ExecuteScalar
  - ExecuteScalar with Parameter
  - Insert
  - Insert with Parameter
  - Output Parameter
  - Transaction Processing
