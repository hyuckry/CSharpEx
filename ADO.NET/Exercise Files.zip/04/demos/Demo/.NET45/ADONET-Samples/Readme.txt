﻿ADO.NET Samples
----------------------------------------------
DataReaderControl - Using the SqlDataReader
  - DataReader
  - DataReader to Generic List<Product>
  - Using an Extension Method to Read Data
  - Multiple Result Sets

NOTES
--------------------------------------
Data readers are read-only, forward-only cursors
Until you close a data reader, no other operations can be done on that connection