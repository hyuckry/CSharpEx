﻿ADO.NET Samples
----------------------------------------------
ExceptionControl - Using the DbException and SqlException classes
  - Normal Exception handling
  - Using the SqlException
  - Getting SqlCommand information
