﻿ADO.NET Samples
----------------------------------------------
DataRowColumnControl - Using the DataRow and DataColumn Classes
  - Loop through all rows/columns in DataTable
  - Build DataTable from scratch
  - Clone()
  - Copy()
  - Select() method
  - Select() method using CopyToDataTable()
