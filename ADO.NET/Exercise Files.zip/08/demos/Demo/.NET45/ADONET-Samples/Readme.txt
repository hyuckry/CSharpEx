﻿ADO.NET Samples
----------------------------------------------
BuilderControl - Using the CommandBuilder and ConnectionStringBuilder classes
  - Break apart connection string
  - Create connection string
  - Create data modification commands
  - Insert using data modification command

CommandBuilder for Update and Delete uses optimistic concurrency, so it only modifies or deletes if all the original values are still in the row prior to updating or deleting