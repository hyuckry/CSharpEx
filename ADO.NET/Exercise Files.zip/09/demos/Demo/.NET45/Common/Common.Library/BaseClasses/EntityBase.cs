﻿using System.ComponentModel.DataAnnotations.Schema;

namespace Common.Library.BaseClasses
{
  public class EntityBase
  {
  }
}
