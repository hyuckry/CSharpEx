﻿DataWrapper.Samples.DataLayer
------------------------------------------
This project is for...
  Entity classes you need to work with data returned from your database
  Manager classes for submitting SQL statements to the database
