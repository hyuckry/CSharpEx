﻿using System.Windows.Controls;

namespace DataWrapper.Samples.UserControls
{
  public partial class ProductDetail : UserControl
  {
    public ProductDetail()
    {
      InitializeComponent();
    }    
  }
}
